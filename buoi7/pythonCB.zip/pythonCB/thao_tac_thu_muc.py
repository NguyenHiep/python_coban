import os
print(os.getcwd())
#os.mkdir('thu_vien')
print(os.path.exists('thu_vien/xl_file1.py'))