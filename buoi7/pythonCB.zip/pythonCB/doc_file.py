f=open('bai_tho.txt','r')
noi_dung=f.read()
f.close()
print(noi_dung)