from xl_file_text import *
tt=1
while tt==1:
    print("1. Tao file moi")
    print("2. mo file")
    print("3. Them noi dung")
    print("4. Doi ten file")
    print("5. Xoa file")
    chon=int(input('Chon chuc nang: \t'))
    if chon==1:
        ten=input('cho biet ten file')
        noi_dung=input('Cho biet noi dung ghi')
        ghi_file(ten,'w',noi_dung)
    elif chon==2:
        ten=input('cho biet ten file')
        doc_file(ten)
    elif chon==3:
        ten=input('cho biet ten file')
        them_noi_dung(ten)
    elif chon==4:
        ten=input('cho biet ten file can doi')
        ten_moi=input('cho biet ten file moi')
        if doi_ten_file(ten,ten_moi)==1:
            print("Da doi ten file")
        else:
            print("Doi ten file khong thanh cong")
    tt=int(input('Ban cho muon tiep tuc (1:tt)\t'))

