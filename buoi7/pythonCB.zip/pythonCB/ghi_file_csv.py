from xl_file_csv import *
list_kh=[]
for i in range(1,10):
    kh=['000'+str(i),'nguyen van ' + str(i),"dia chi " + str(i)]
    list_kh.append(kh)
ghi_file('Bang_tinh_csv',list_kh)
