import csv
def doc_tung_dong(path):
    f=open(path)
    noi_dung=csv.reader(f)
    for dong in noi_dung:
        print(dong)
    
    f.close()
def ghi_file(path,list_noi_dung):
    f=open(path,'a',newline='')
    for dong in list_noi_dung:
        csv.writer(f).writerow(dong)
    f.close()