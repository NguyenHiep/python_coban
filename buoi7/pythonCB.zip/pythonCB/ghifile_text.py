f=open('bai_tho.txt','w')
noi_dung="Cong hoa xa hoi chu nghia viet nam\n"
noi_dung+="Doc lap tu do hanh phuc"
f.write(noi_dung)
f.close()