from xl_file_text import *
ten_file=input('Cho biet ten file')
thong_ke(ten_file)